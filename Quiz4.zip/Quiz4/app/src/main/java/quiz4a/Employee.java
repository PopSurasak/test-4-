package quiz4a;


// (1.1) เขียน Java Docs
/*สร้างclass Employee ตั้งค่าเป็น private เพื่อไม่ให้มาเปลี่ยนได้ เพิ่มตัวแปรคือ int ตัวเลข คือ employee String ตัวอักษร คือ name Double ตัวเลข คือ salary*/
public class Employee {
    private int employeeId;
    private String name;
    private double salary;

    // (1.2)
    /*เก็บค่าของตัวแปร int = employeeId คือเลขไอดี String = name คือ ชื่อ double = salary คือ การคำนวณ salary มากกว่า 0*/
    public Employee(int employeeId, String name, double salary) {
        this.employeeId = employeeId;
        this.name = name;
        this.salary = (salary > 0) ? salary : 0;
    }

    // (1.3) 
    /*เงินเดือนเท่าไหร่ ห้ามน้อยกว่า 0 */
    public double calculateSalary() {
        return salary;
    }

    // (1.4) 
    /*ใส่เลขไอดี*/
    public int getEmployeeId() {
        return employeeId;
    }

    // (1.5) 
    /*ใส่ชื่อ*/
    public String getName() {
        return name;
    }
}