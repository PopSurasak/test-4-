package quiz4a;

// 2.1 
/*สร้างclassผูจัดการและสืบทอดพนักงาน*/
public class Manager extends Employee {
    private String department;
    private double bonus;

    
    // 2.2
    /*เก็บค่า int = employeeId คือ ไอดี String = name คือ ชื่อ double = salary คือ เงินเดือน String = departamet คือ แผนก double=bonus คือ โบนัส*/
    public Manager(int employeeId, String name, double salary, String department, double bonus) {
        super(employeeId, name, salary);
        this.department = department;
        this.bonus = bonus;
    }

    // 2.3 
    /*method ของพนักงาน มีเลขไอดี ชื่อ เงินเดือน แผนก โบบัส*/
    public void displayDetails() {
        String[] details = {
            "Employee ID: " + getEmployeeId(),
            "Name: " + getName(),
            "Salary: " + calculateSalary(),
            "Department: " + department,
            "Bonus: " + bonus
        };
        for (String detail : details) {
            System.out.println(detail);
        }
    }

    //2.4  
    /*method ของพนักงาน มีเลขไอดี ชื่อ เงินเดือน แผนก โบบัส*/
    public void displayDetails(String condition) {
        if ("full".equalsIgnoreCase(condition)) {

            String[] details = {
                "Employee ID: " + getEmployeeId(),
                "Name: " + getName(),
                "Salary: " + calculateSalary(),
                "Department: " + department,
                "Bonus: " + bonus
            };
            for (String detail : details) {
                System.out.println(detail);
            }
        } else {

            String[] details = {
                "Employee ID: " + getEmployeeId(),
                "Name: " + getName()
            };
            for (String detail : details) {
                System.out.println(detail);
            }
        }
    }
}
